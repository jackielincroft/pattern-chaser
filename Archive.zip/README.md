// CLIPBOARD:
- not yet functional toggle for knit/crochet:
<div class="btn-group btn-group-toggle" data-toggle="buttons">
    <label class="btn btn-secondary active">
        <input type="radio" id="option1" name="options" autocomplete="off" checked>
        Knitting
    </label>
    <label class="btn btn-secondary">
        <input type="radio" id="option2" name="options" autocomplete="off" >
        Crochet
    </label>
</div>